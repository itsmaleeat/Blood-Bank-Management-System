<?php
	include('connection.php');
	session_start();
	session_destroy();
	$_SESSION=['member_id']; ?>
	<script type="text/javascript">
		window.location = "../index.php";
	</script>
	<?php ?>