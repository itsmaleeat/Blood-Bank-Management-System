<?php 
	include('connection.php');

	session_start();
	session_destroy();
	$_SESSION=['member_id'];session_destroy();
	header('location:index.php');
?>